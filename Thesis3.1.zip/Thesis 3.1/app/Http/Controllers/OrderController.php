<?php

namespace App\Http\Controllers;
use App\InventoryModel;
use App\ServicesModel;
use App\ClientsModel;
use App\OrdersModel;
use App\OrderDetailsModel;
use App\SalesModel;
use App\CustomizeModel;

use Auth;
use Carbon\Carbon;
use DB;
use Helper;

use Illuminate\Http\Request;

class OrderController extends Controller
{
    private $inventory;
    private $order;

    public function __construct(InventoryModel $inventory, OrdersModel $order)
    {
        $this->inventory=$inventory;
        $this->order=$order;
        date_default_timezone_set('Asia/Manila'); 
    }

    public function index()
    {
        $currentUser = Helper::staticInfo();
        // $order = DB::table('inventory')->get();
        return view('client_module.order_summary_pc', compact('currentUser'));

    }

    public function customIndex()
    {
        $currentUser = Helper::staticInfo();
        $inventories =  DB::table('inventory')
            ->groupBy('inventory_item')
            ->where('inventory_status', '=', 'Available')
            ->get();

        return view('client_module.customize', compact('currentUser', 'inventories'));
    }


    //display pc build summary
    public function viewSummary(Request $request)
    {
        // return $request;
        //store client info in array
        $client = array($request->input('fname'), $request->input('lname'), $request->input('contact'), $request->input('category'), $request->input('or_no'));

        // //get id's and costs get item names for display
        // $order['motherboard'] = $_GET['motherboard'];
        // $order['processor'] = $_GET['processor'];
        // $order['memory'] = $_GET['memory'];
        // $order['graphics'] = $_GET['graphics'];
        // $order['os'] = $_GET['os'];
        // $order['office'] = $_GET['office'];
        // $order['power'] = $_GET['power'];
        // $order['cooling'] = $_GET['cooling'];
        // $order['fan'] = $_GET['fan'];
        // $order['monitor'] = $_GET['monitor'];
        // $order['mouse'] = $_GET['mouse'];
        // $order['keyboard'] = $_GET['keyboard'];
        // $order['headset'] = $_GET['headset'];
        $order['cpu'] = $request->input('cpu') == null ? array('NONE') : $request->input('cpu');
        $order['motherboard'] = $request->input('motherboard') == null ? array('NONE') : $request->input('motherboard');
        $order['gpu'] = $request->input('gpu') == null ? array('NONE') : $request->input('gpu');
        $order['memory'] = $request->input('memory') == null ? array('NONE') : $request->input('memory');
        $order['os'] = $request->input('os') == null ? array('NONE') : $request->input('os');
        $order['office'] = $request->input('office') == null ? array('NONE') : $request->input('office');
        $order['power'] = $request->input('power') == null ? array('NONE') : $request->input('power');
        $order['cooling'] = $request->input('cooling') == null ? array('NONE') : $request->input('cooling');
        $order['fan'] = $request->input('fan') == null ? array('NONE') : $request->input('fan');
        $order['monitor'] = $request->input('monitor') == null ? array('NONE') : $request->input('monitor');
        $order['mouse'] = $request->input('mouse') == null ? array('NONE') : $request->input('mouse');
        $order['keyboard'] = $request->input('keyboard') == null ? array('NONE') : $request->input('keyboard');
        $order['headset'] = $request->input('headset') == null ? array('NONE') : $request->input('headset');

        

        $currentUser = Helper::staticInfo();
        return view('client_module.order_summary_pc', compact('currentUser', 'order', 'client'));
    }

}
